list= ['첫','두','세','네','다섯']
sum = 0
for i in range(5):
    a = int(input(list[i] + " 번째 숫자를 입력해주세요 "))
    sum += a
    print(sum)
