a = int(input("첫 번째 숫자를 입력해주세요 "))
b = int(input("두 번째 숫자를 입력해주세요 "))
c = int(input("세 번째 숫자를 입력해주세요 "))
d = int(input("네 번째 숫자를 입력해주세요 "))
e = int(input("다섯 번째 숫자를 입력해주세요 "))
list = [a,b,c,d,e]
print(list)