a = input("첫 번째 문장을 입력해주세요 ")
b = input("두 번째 문장을 입력해주세요 ")
print(a+b)