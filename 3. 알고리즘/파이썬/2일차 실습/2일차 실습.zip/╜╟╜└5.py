a = int(input("정수를 입력하세요 "))
if a<=100 and a>=60:
    print("합격")
elif a>=0 and a<60:
    print("불합격")
else:
    print("에러")
