a = int(input("첫 번째 정수를 입력하세요 "))
b = int(input("두 번째 정수를 입력하세요 "))
if a>b:
    print(a)
elif a!=b:
    print(b)
else:
    print(False)