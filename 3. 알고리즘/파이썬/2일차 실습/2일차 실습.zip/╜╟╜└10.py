for i in range(8):
    for j in range(8):
        print(str((i+2))+" X "+str((j+2))+" = "+str((i+2)*(j+2)))