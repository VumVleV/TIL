a=int(input("정수를 입력하세요 "))
if a%2==0:
    print(True)
else:
    print(False)