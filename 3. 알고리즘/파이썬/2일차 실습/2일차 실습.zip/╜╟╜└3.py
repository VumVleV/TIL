a = int(input("정수를 입력하세요 "))
if a>1 and a<10:
    print(True)
else:
    print(False)