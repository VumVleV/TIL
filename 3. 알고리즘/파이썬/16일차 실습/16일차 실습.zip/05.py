d = {}
cnt = 0
i = 0
p = 666
N = int(input())
while cnt != N:
    i+=1
    if '666' in str(i):
        cnt+=1
        p = i
print(p)