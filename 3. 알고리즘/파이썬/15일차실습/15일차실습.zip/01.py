a = int(input())
for i in range(a):
    print(' '*i,'*'*(a-i),sep='')