a = input().split()
for char in a:
    print(char,end = ' ')