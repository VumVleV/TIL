a = map(int,input().split())
for num in a:
    print(num,end = ' ')