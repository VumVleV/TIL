a = [x for x in input().split()]
print(int(a[0]+a[1]) + int(a[2]+a[3]))