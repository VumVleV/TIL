a = input("문자열을 입력하세요 ")
count = 0
for char in a:
    count += 1
print(count)
