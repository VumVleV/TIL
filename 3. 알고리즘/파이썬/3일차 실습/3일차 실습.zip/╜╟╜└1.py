a = int(input("정수를 입력하세요: "))
if a>=0:
    print(a)
else:
    print(-a)