number_list = []
count = 0
for i in range(len(number_list)):
    count += number_list[i]
print(count)