number_list = [-1]
product = 1
for i in range(len(number_list)):
    product = product * number_list[i]

if(len(number_list)!=0):
        print(product)