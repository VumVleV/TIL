number_list = [1, 2, 3, 4, 5]
number_list.sort()
print(number_list[0])