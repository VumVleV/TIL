number_list = []
count = 0
for char in number_list:
    count+=1
print(count)