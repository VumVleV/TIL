number_list = [1, 1, 1]
number_list.sort(reverse = True)
print(number_list[0])
