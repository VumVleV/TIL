T = int(input())
for i in range(T):
    N = int(input())
    for j in range(N):
        print(j+1)