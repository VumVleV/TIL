T = int(input())
for i in range(T):
    N = int(input())
    for j in range(N):
        print(f"{j+1} {j+1}")
