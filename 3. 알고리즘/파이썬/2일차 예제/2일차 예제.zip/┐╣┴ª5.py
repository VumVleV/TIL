string = "Hello World!"

for element in string:
    print(element)

"""
H
e
l
l
o

W
o
r
l
d
!

"""
# 문자열은 뒤에 NULL값을 갖기 때문에 공백이 출력된다?
# a = int( )
# print("\n"+str(a)) >>> 0
