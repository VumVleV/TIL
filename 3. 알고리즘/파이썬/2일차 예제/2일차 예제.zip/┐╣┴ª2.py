a = bool("")
b = False
print(a==b) # True