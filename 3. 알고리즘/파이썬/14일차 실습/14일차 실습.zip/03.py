a = int(input())
for i in range(9):
    print(f"{a} * {i+1} = {(i+1)*a}")