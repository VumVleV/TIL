list_variable = [3,1,4,-3,9,7]
print(min(list_variable) - max(list_variable)) #-12