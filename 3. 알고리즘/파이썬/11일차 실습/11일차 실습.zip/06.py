T = int(input())
d=[]
for i in range(T):
    b, c = input().split()
    if c == 'enter':
        d.append(b)
        d.sort(reverse=True)
    elif c == 'leave' and b in d:
        d.remove(b)
for j in range(len(d)):
    print(d[j])