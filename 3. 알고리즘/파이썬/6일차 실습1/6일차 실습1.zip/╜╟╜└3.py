T = int(input())
for i in range(T):
    a = input()
    print(a)