string= input().split()
for i in range(len(string)):
    print(string[i],end=' ')