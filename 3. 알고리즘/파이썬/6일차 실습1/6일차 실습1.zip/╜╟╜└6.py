a = input().split()
for i in range(len(a)):
    print(a[i],end=' ')
