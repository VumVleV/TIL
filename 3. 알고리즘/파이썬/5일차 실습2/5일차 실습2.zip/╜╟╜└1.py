a = input()
count = 0
for char in a:
    count += 1
    if char == 'e':
        print(count)
        break
        
