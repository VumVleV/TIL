a = input().split()
count = 0
for char in a[0]:
    if char == a[1]:
        count += 1
print(count)
