a = input()
for char in a:
    if char != 'e':
        print(char,end='')
    else:
        continue

