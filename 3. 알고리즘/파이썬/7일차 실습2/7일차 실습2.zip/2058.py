a = int(input())
b = str(a)
cnt = 0
for char in b:
    cnt += int(char)
print(cnt)