for i in range(5):
    print("+"*i + "#" + "+"*(4-i))