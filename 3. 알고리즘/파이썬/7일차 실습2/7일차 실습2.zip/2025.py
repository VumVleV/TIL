a = int(input())
cnt = 0
for i in range(a):
    cnt += (i+1)
print(cnt)