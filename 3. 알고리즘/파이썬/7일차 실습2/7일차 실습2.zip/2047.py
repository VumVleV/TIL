a = input().upper()
print(a)