a = int(input())
for i in range(a+1):
    print(2**i,end=' ')