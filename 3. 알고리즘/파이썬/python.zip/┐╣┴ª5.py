string = "abc hello def"
sub_string1 = string[4:10]
sub_string2 = string[1:4]
sub_string3 = string[-1]

print(sub_string1)
print(sub_string2)
print(sub_string3)
# hello 
# bc 
# f
# 자동 줄바뀜