list_variable = [1,2,3,[1,2,3]]
sub_list = list_variable[3][-1]
print(sub_list) # 3