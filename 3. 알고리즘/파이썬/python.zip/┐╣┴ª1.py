number1 = 1
number2 = number1 + 1
print(number1, number2) # 1 2
# 자동 띄어쓰기 해준다?