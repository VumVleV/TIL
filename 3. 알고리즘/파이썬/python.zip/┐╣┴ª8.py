list_variable = []
list_variable.append(1)
list_variable.append("a")
list_variable[0] = 0
print(list_variable) # [0,'a']
# 출력은 작은 따옴표로 한다