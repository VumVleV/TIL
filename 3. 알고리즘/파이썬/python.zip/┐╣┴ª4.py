string = "Hello?"
n = 5

print(string*n) # Hello?Hello?Hello?Hello?Hello?