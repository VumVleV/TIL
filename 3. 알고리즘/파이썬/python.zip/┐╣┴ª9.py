name = input("너의 이름은?")
print(name) # 입력한 이름을 받는다