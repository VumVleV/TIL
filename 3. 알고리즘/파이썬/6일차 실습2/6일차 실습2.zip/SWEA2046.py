T = int(input())
for i in range(T):
    print("#",end='')